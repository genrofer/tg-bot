module.exports = {
    connectionString: 'postgres://qwruqlyf:Vio4Llj4uTyBu5boPEel3XINEtN_OODf@tai.db.elephantsql.com/qwruqlyf'
}    